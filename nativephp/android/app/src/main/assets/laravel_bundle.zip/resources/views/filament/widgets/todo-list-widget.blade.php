<x-filament-widgets::widget>
    <div wire:ignore>
        @livewire(\App\Livewire\Mingles\TodoListReact::class)
    </div>
</x-filament-widgets::widget>
