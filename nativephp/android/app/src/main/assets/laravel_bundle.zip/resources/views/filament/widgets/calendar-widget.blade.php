<x-filament-widgets::widget>
    <div wire:ignore>
        @livewire(\App\Livewire\Mingles\CalendarReact::class)
    </div>
</x-filament-widgets::widget>
